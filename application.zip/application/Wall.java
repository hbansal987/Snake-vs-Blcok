package application;

import java.io.Serializable;

import javafx.animation.PathTransition;
import javafx.scene.shape.Line;
import javafx.util.Duration;

public class Wall implements Serializable {
	private int positionX;
	private int positionY;
	private int wall_size;
	private Line wall_line;
	private PathTransition transition2;
	public double speed;
	

	public PathTransition getTransition2() {
		return transition2;
	}

	public void setTransition2(PathTransition transition) {
		this.transition2 = transition;
	}

	public Line getWall_line() {
		return wall_line;
	}

	public void setWall_line(Line wall_line) {
		this.wall_line = wall_line;
	}

	public int getWall_size() {
		return wall_size;
	}

	public void setWall_size(int wall_size) {
		this.wall_size = wall_size;
	}

	public int getPositionX() {
		return positionX;
	}

	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}

	public int getPositionY() {
		return positionY;
	}

	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}

	public Wall() {
		positionX=0;
		positionY=0;
	}
	
	public void makeWall(GameState gameState, int z1,int z2, int z3) {
		
		Line line= new Line(z1*100,-z2+50,z1*100,1100-z2+50);
		PathTransition transition = new PathTransition();
		transition.setNode(getWall_line());
		transition.setDuration(Duration.seconds(6 - (gameState.getSnake().getLength()/10)/2));
		speed=6 - (gameState.getSnake().getLength()/10)/2;
		transition.setPath(line);
		setTransition2(transition);
		transition.play();	
}
	
	
}
