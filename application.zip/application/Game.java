package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Optional;
import java.util.Random;

import javafx.animation.AnimationTimer;
import javafx.animation.PathTransition;
import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Game extends Application implements Serializable {
	LinkedList<LeaderBoard> ranks;

	private GameState gameState;
	public int stopGame;
	private ArrayList<LeaderBoard> leaderboard = new ArrayList<LeaderBoard>();
	private int speed;
	Scene scene_game, scene_leader, scene_new;
	Button newGame, resumeGame, viewLeaderBoard, exitGame;
	ChoiceBox<String> choicebox;
	public static Label newlabel, length_label, score_label;
	ImageView MagnetToken, ShieldToken, DestroyToken, BallToken;
	String playerName;
	int col = 0;
	int col2=0;

	public Game() {

		gameState = new GameState(this);
		ranks = new LinkedList<LeaderBoard>();
		

		// Make Main Screen
		ImageView main_image = new ImageView();
		Image mainImage = new Image("/application/snake-vs-block.png");
		main_image.setImage(mainImage);
		main_image.setX(15);
		main_image.setY(40);
		gameState.t = 0;

		main_image.setFitHeight(500);
		main_image.setFitWidth(500);

		newGame = new Button("New Game");
		resumeGame = new Button("Resume Game");
		viewLeaderBoard = new Button("View LeaderBoard");
		exitGame = new Button("Exit Game");
		int firstPad = 500;
		int padding = 60;
		Pane root = new Pane();
		root.getChildren().addAll(newGame, resumeGame, viewLeaderBoard, main_image, exitGame);
		scene_game = new Scene(root, 500, 800);
		root.setStyle("-fx-background-color: black");

		String buttonStyle = "-fx-background-color: linear-gradient(#ffd65b, #e68400),linear-gradient(#ffef84, #f2ba44), linear-gradient(#ffea6a, #efaa22),linear-gradient(#ffe657 0%, #f8c202 50%, #eea10b 100%),linear-gradient(from 0% 0% to 15% 50%, rgba(255,255,255,0.9), rgba(255,255,255,0)); -fx-background-radius: 30;-fx-background-insets: 0,1,2,3,0;-fx-text-fill: #654b00;-fx-font-weight: bold;-fx-font-size: 14px;-fx-padding: 10 20 10 20";
		newGame.setStyle(buttonStyle);
		newGame.setPrefWidth(400);
		newGame.setTranslateX(250 - (newGame.getPrefWidth()) / 2);
		newGame.setTranslateY(firstPad);

		resumeGame.setStyle(buttonStyle);
		resumeGame.setPrefWidth(400);
		resumeGame.setTranslateX(250 - (resumeGame.getPrefWidth()) / 2);
		resumeGame.setTranslateY(firstPad + padding);

		viewLeaderBoard.setStyle(buttonStyle);
		viewLeaderBoard.setPrefWidth(400);
		viewLeaderBoard.setTranslateX(250 - (viewLeaderBoard.getPrefWidth()) / 2);
		viewLeaderBoard.setTranslateY(firstPad + padding + padding);

		exitGame.setStyle(buttonStyle);
		exitGame.setPrefWidth(400);
		exitGame.setTranslateX(250 - (exitGame.getPrefWidth()) / 2);
		exitGame.setTranslateY(firstPad + padding + padding + padding);
		// End of making main screen
	}

	public GameState getGameState() {
		return gameState;
	}

	public void setGameState(GameState gameState) {
		this.gameState = gameState;
	}

	public static void main(String[] args) {
		launch(args);
	}

	public void addToLeaderBoard(String name, int score) {

		ranks.add(new LeaderBoard(name, score));
		Collections.sort(ranks);
		while (ranks.size() > 10) {
			ranks.remove(ranks.getLast());
			System.out.println("leaderboard index : " + ranks.size());
		}

	}

	public boolean addToLeaderBoard(int prospectiveScore) {
		if (prospectiveScore > getLeaderBoardMin()) {
			TextInputDialog dialog = new TextInputDialog("Name");
			String name;
			dialog.setTitle("Congratulations!");
			dialog.setHeaderText("You made it to the leaderboard!");
			dialog.setContentText("Enter Name: ");
			Optional<String> result = dialog.showAndWait();
			if (result.isPresent()) {
				name = result.get();
				System.out.println("Hi, " + name + "!");
				addToLeaderBoard(name, prospectiveScore);
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public int getLeaderBoardMin() {
		if (ranks.size() < 10) {
			return 0;
		} else {
			return ranks.getLast().score;
		}
	}

	@Override
	public void start(Stage primaryStage) throws Exception {

		Media musicFile= new Media(new File("background.mp3").toURI().toString());
		gameState.mp= new MediaPlayer(musicFile);
		
		primaryStage.setResizable(false);
		primaryStage.setTitle("Snake Vs Block");
		primaryStage.setScene(scene_game);
		primaryStage.show();

		newGame.setOnAction(e -> {
			
			gameplay(primaryStage);
			
		});
		viewLeaderBoard.setOnAction(e -> {
			LeaderBoardMethod(primaryStage);
		});

		scene_game.setOnMouseMoved(e -> {
			if (gameState.getSnake().prevScore != -1) {
//				System.out.println("add to lb");
				addToLeaderBoard(gameState.getSnake().prevScore);
				gameState.getSnake().prevScore = -1;
			} else {
//				System.out.println("nothing doing");
			}
		});

		resumeGame.setOnAction(e -> {
			
			gameState.pane= new Pane();
			
			BufferedReader in = null;
			gameState.setSnake(new Snake(gameState));
			
			try {
				in = new BufferedReader(new FileReader("snakeinfo.txt"));
			} catch (FileNotFoundException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			String l;
			double x = 0;
			double y= 0;
			int c=0;
			try {
				while ((l = in.readLine()) != null) {
					if(c==0) {
						x= Double.parseDouble(l);
						c=1;
					}
					else if(c==1) {
						y= Double.parseDouble(l);
						c=2;
					}
					else if(c==2) {
						gameState.getSnake().setLength(Integer.parseInt(l));
						c=3;
					}
					else if(c==3) {
						gameState.getSnake().time= Double.parseDouble(l);
						c=4;
					}
					else if(c==4) {
						gameState.getSnake().value= Integer.parseInt(l);
						c=0;
					}
				}
				
				ArrayList<Circle> arr_snake= new ArrayList<Circle>();
				for(int a=0;a<gameState.getSnake().getLength();a++) {
					Circle cir= new Circle(10);
					cir.setFill(Color.WHITE);
					cir.setCenterX(x);
					cir.setCenterY(y+(a*20));
					arr_snake.add(cir);
				}
				
				gameState.getSnake().setSnake_arr(arr_snake);
				gameState.pane.getChildren().addAll(gameState.getSnake().getSnake_arr());
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			BufferedReader in2 = null;
			try {
				in2 = new BufferedReader(new FileReader("blockinfo.txt"));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String l2;
			int c2=0;
			ArrayList<Block> arr_block= new ArrayList<Block>();
			
			try {
				Block blk = null;
				while ((l2 = in2.readLine()) != null) {
					
					if(c2==0) {
						int v=(Integer.parseInt(l2));
						gameState.flag=gameState.flag+1;
						blk= new Block(v);	
						blk.setBlockVal(v);
						blk.getValue().setText(Integer.toString(v));
						c2=1;
					}
					else if(c2==1) {
						blk.getShape().setTranslateX(Double.parseDouble(l2));
						c2=2;
					}
					else if(c2==2) {
						blk.getShape().setTranslateY(Double.parseDouble(l2));
						c2=3;
					}
					else if(c2==3) {
						blk.blown=Integer.parseInt(l2);
						c2=4;
					}
					else if(c2==4) {
						blk.speed= Double.parseDouble(l2);
						c2=0;
						double temp=0;
						if(blk.getShape().getTranslateY()>0) {
							temp= -blk.getShape().getTranslateY();
						}
						else {
							temp=blk.getShape().getTranslateY();
						}
						Line line= new Line(blk.getShape().getTranslateX()+50,blk.getShape().getTranslateY(),blk.getShape().getTranslateX()+50,1100-temp);
						PathTransition trans= new PathTransition();
						trans.setNode(blk.getShape());
						trans.setDuration(Duration.seconds(blk.speed));
						trans.setPath(line);
						blk.setTransition1(trans);
						trans.play();
						
						Line line2= new Line(blk.getShape().getTranslateX()+50,blk.getShape().getTranslateY(),blk.getShape().getTranslateX()+50,1100-temp);
						PathTransition trans2= new PathTransition();
						trans2.setNode(blk.getValue());
						trans2.setDuration(Duration.seconds(blk.speed));
						trans2.setPath(line2);
						blk.setTransition2(trans2);
						trans2.play();
						
						arr_block.add(blk);
						c=0;
						gameState.pane.getChildren().addAll(blk.getShape(),blk.getValue());
					}
				}
				
				gameState.setBlock_arr(arr_block);
				
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			ArrayList<Wall> arr_wall= new ArrayList<Wall>();
			
			BufferedReader in3 = null;
			try {
				in3 = new BufferedReader(new FileReader("wallinfo.txt"));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			String l3;
			int t=0;
			double x2=0;
			double y2=0;
			try {
				Line line = null;
				int size=0;
				while ((l3 = in3.readLine()) != null) {
					if(t==0) {
						
						x2= Double.parseDouble(l3);
						System.out.println(x2);
						t=1;
					}
					else if(t==1) {
						
						y2= Double.parseDouble(l3);
						System.out.println(y2);
						t=2;
					}
					else if(t==2) {
						size= Integer.parseInt(l3);
						line= new Line(x2,y2,x2,y2+size);
						t=3;
					}
					else if(t==3) {
						Wall w= new Wall();
						w.speed= Double.parseDouble(l3);
						w.setWall_line(line);
						w.setWall_size(size);
						w.getWall_line().setTranslateX(x2);
						w.getWall_line().setTranslateY(y2);
						w.getWall_line().setStroke(Color.WHITE);
						w.getWall_line().setStrokeWidth(5);
						
						double temp=0;
						if(y2>0) {
							temp=-y2;
						}
						else {
							temp=y2;
						}
						
						Line li= new Line(x2,y2,x2,1100-temp);
						PathTransition trans= new PathTransition();
						trans.setNode(w.getWall_line());
						trans.setDuration(Duration.seconds(w.speed));
						trans.setPath(li);
						w.setTransition2(trans);
						trans.play();
						arr_wall.add(w);
						System.out.println("him");
						gameState.pane.getChildren().add(w.getWall_line());
						t=0;
					}
					
					gameState.setWall_arr(arr_wall);
					
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			BufferedReader in4 = null;
			try {
				in4 = new BufferedReader(new FileReader("gamestateinfo.txt"));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String l4=null;
			int p=0;
			try {
				while ((l4 = in4.readLine()) != null) {
					if(p==0) {
						gameState.flag=Integer.parseInt(l4);
						p=1;
					}
					else if(p==1) {
						gameState.score= Integer.parseInt(l4);
						p=2;
					}
					else if(p==2) {
						gameState.index2= Integer.parseInt(l4);
						p=3;
					}
					else if(p==3) {
						gameState.ShieldOn= Integer.parseInt(l4);
						p=4;
					}
					else if(p==4) {
						gameState.old_timer= Integer.parseInt(l4);
						p=5;
					}
					else if(p==5) {
						gameState.old_timer2= Integer.parseInt(l4);
						p=6;
					}
					else if(p==6) {
						gameState.count2= Integer.parseInt(l4);
						p=7;
					}
					else if(p==7) {
						gameState.isResume= Integer.parseInt(l4);
						p=8;
					}
					else if(p==8) {
						gameState.blockOn= Integer.parseInt(l4);
						p=9;
					}
					else if(p==9) {
						gameState.flagWall= Integer.parseInt(l4);
						p=10;
					}
					else if(p==10) {
						gameState.magnetOn= Integer.parseInt(l4);
						p=11;
					}
					else if(p==11) {
						gameState.t= Integer.parseInt(l4);
						p=0;
					}
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			BufferedReader in5 = null;
			try {
				in5 = new BufferedReader(new FileReader("tokeninfo.txt"));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			String l5=null;
			int d=0;
			double x3=0;
			double y3=0;
			String n=null;
			
			ArrayList<Token> arr_token= new ArrayList<Token>();
			Token to= null;
			try {
				while ((l5 = in5.readLine()) != null) {
					if(d==0) {
						n=l5;
						d=1;
						if(n.equals("ball")) {
							to= new BallToken();
							ImageView iview= new ImageView();
							Image ima = new Image("/application/ball.png");
							iview.setImage(ima);
							to.setPicture(iview);
						}
						else if(n.equals("destroy")) {
							to= new DestroyToken();
							ImageView iview= new ImageView();
							Image ima = new Image("/application/blast.png");
							iview.setImage(ima);
							to.setPicture(iview);
						}
						else if(n.equals("magnet")) {
							to= new MagnetToken();
							ImageView iview= new ImageView();
							Image ima = new Image("/application/magnet.png");
							iview.setImage(ima);
							to.setPicture(iview);
						}
						else if(n.equals("shield")) {
							to= new ShieldToken();
							ImageView iview= new ImageView();
							Image ima = new Image("/application/shield.png");
							iview.setImage(ima);
							to.setPicture(iview);
						}
						
					}
					else if(d==1) {
						x3= Double.parseDouble(l5);
						d=2;
					}
					else if(d==2) {
						y3= Double.parseDouble(l5);
						d=3;
					}
					else if(d==3) {
						to.setIsCollide(Integer.parseInt(l5));
						d=4;
					}
					else if(d==4) {
						to.setBall_value(Integer.parseInt(l5));
						d=5;
						
						Label lab= new Label();
						lab.setText(Integer.toString(to.getBall_value()));
						lab.setStyle("-fx-text-fill:white");
						to.setBall_label(lab);
						
						
					}
					else if(d==5) {
						to.speed= Double.parseDouble(l5);
						d=0;
						double temp=0;
						if(y3>0) {
							temp=-y3;
						}
						else {
							temp=y3;
						}
						Line lin= new Line(x3,y3,x3,1100-temp);
						PathTransition trans= new PathTransition();
						trans.setNode(to.getPicture());
						trans.setDuration(Duration.seconds(to.speed));
						trans.setPath(lin);
						to.setTransition(trans);
						trans.play();
						
						Line lin2= new Line(x3,y3-30,x3,1100-temp-30);
						PathTransition trans2= new PathTransition();
						trans2.setNode(to.getBall_label());
						trans2.setDuration(Duration.seconds(to.speed));
						trans2.setPath(lin2);
						to.setTransition2(trans2);
						trans2.play();
						
						arr_token.add(to);
						gameState.pane.getChildren().addAll(to.getPicture(),to.getBall_label());
						
					}
					
					gameState.setToken_arr(arr_token);
					
					
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
			
			gameState.isResume = 1;
			gameplay(primaryStage);
		});
		exitGame.setOnAction(e -> primaryStage.close());
	}

	public void LeaderBoardMethod(Stage primaryStage) {
		Pane top = new Pane();
		Label leaderLabel = new Label("Leaderboard");
		leaderLabel.setStyle(
				"-fx-background-color: transparent; -fx-text-fill: yellow; -fx-font-size: 35px; -fx-font-family: \"Impact\";-fx-alignment: center ;");
		top.getChildren().add(leaderLabel);
		leaderLabel.setPrefWidth(300);
		scene_leader = new Scene(top, 500, 800);
		leaderLabel.setTranslateX(250 - 150);
		leaderLabel.setTranslateY(20);

		for (int i = -1; i < ranks.size() && i < 10; i++) {
			Label l1, l2, l3;
			String stylePreset;
			if (i == -1) {
				l1 = new Label("Name");
				l2 = new Label("Score");
				l3 = new Label("Date");
				stylePreset = "-fx-background-color: transparent; -fx-text-fill: blue; -fx-font-size: 20px; -fx-font-family: \"Impact\";-fx-alignment: center ;";
			} else {
				l1 = new Label((i + 1) + ". " + ranks.get(i).name);
				l2 = new Label("" + ranks.get(i).score);
				l3 = new Label(ranks.get(i).dateString);
				stylePreset = "-fx-background-color: transparent; -fx-text-fill: red; -fx-font-size: 20px; -fx-font-family: \"Impact\";-fx-alignment: center ;";
			}

			l1.setTranslateX(20);
			l2.setTranslateX(230);
			l3.setTranslateX(330);

			l1.setStyle(stylePreset);
			l2.setStyle(stylePreset);
			l3.setStyle(stylePreset);

			int yLine = 40;
			int yFirst = 200;
			l1.setTranslateY(yFirst + (i * yLine));
			l2.setTranslateY(yFirst + (i * yLine));
			l3.setTranslateY(yFirst + (i * yLine));

			top.getChildren().addAll(l1, l2, l3);
		}

		// Setting of button
		Button backButton = new Button("Back");
		backButton.setOnAction(e -> primaryStage.setScene(scene_game));
		backButton.setStyle(
				"-fx-background-color: linear-gradient(#ffd65b, #e68400),linear-gradient(#ffef84, #f2ba44), linear-gradient(#ffea6a, #efaa22),linear-gradient(#ffe657 0%, #f8c202 50%, #eea10b 100%),linear-gradient(from 0% 0% to 15% 50%, rgba(255,255,255,0.9), rgba(255,255,255,0)); -fx-background-radius: 30;-fx-background-insets: 0,1,2,3,0;-fx-text-fill: #654b00;-fx-font-weight: bold;-fx-font-size: 14px;-fx-padding: 10 20 10 20; -fx-alignment: center ;");
		top.getChildren().add(backButton);
		backButton.setPrefWidth(100);
		backButton.setTranslateX(top.getWidth() / 2 - backButton.getPrefWidth() / 2);
		backButton.setTranslateY(top.getHeight() - 50);
		top.setStyle("-fx-background-color: black");
		primaryStage.setScene(scene_leader);
	}

	public void gameplay(Stage primaryStage) {

		ImageView SnakeLabel = new ImageView();
		Image snakeLabel = new Image("/application/snaketitle.jpg");
		//if (gameState.isResume == 0) {
			SnakeLabel.setImage(snakeLabel);
			SnakeLabel.setFitWidth(500);
			SnakeLabel.setFitHeight(50);
			if(gameState.isResume==0) {
			gameState.pane = new Pane();
			// pane.getChildren().clear();
			gameState.score = 0;
			gameState.setSnake(new Snake(gameState));
			gameState.getSnake().makeSnake(gameState.pane);
			gameState.getSnake().setLength(4);
			gameState.getBlock_arr().clear();
			gameState.getToken_arr().clear();

			gameState.flag = -5;
			gameState.index2 = 0;

			}
			makeChoiceBox(primaryStage);
			
			// Timer Starts
			gameState.timer = new AnimationTimer() {
				public void handle(long now) {
					try {
						onUpdate(primaryStage);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			};
			
			gameState.timer.start();
			gameState.pane.getChildren().addAll(SnakeLabel, choicebox, score_label, length_label);

			scene_new = new Scene(gameState.pane, 500, 800);

			scene_new.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

			gameState.isResume = 0;
		

		

		// Pressing of keys to get inputs
		scene_new.setOnKeyPressed(e -> {
			double snakeOffset = gameState.getSnake().snakeRadius + 5;
			if (e.getCode() == KeyCode.LEFT) {
				double currentX = gameState.getSnake().getSnake_arr().get(0).getCenterX();
				gameState.getSnake().getSnake_arr().get(0)
						.setCenterX(gameState.getSnake().getSnake_arr().get(0).getCenterX() - 10);

				for (int r = 0; r < gameState.getWall_arr().size(); r++) {
					double wallX = gameState.getWall_arr().get(r).getWall_line().getStartX();
					if (isColliding(gameState.getSnake().getSnake_arr().get(0),
							gameState.getWall_arr().get(r).getWall_line())) {
						gameState.getSnake().getSnake_arr().get(0).setCenterX(wallX + snakeOffset);
					}
				}

				for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
					double blockX = gameState.getBlock_arr().get(r).getShape().getTranslateX();
					if (isColliding(gameState.getSnake().getSnake_arr().get(0),
							gameState.getBlock_arr().get(r).getShape())) {
					//	System.out.println("left block called");
						gameState.getSnake().getSnake_arr().get(0).setCenterX(currentX);
					}
				}

				gameState.getSnake().setPositionX(gameState.getSnake().getSnake_arr().get(0).getCenterX());
				updateSpheres(gameState.getSnake().getSnake_arr());
			}

			else if (e.getCode() == KeyCode.RIGHT) {
				double currentX = gameState.getSnake().getSnake_arr().get(0).getCenterX();
				gameState.getSnake().getSnake_arr().get(0).setCenterX(currentX + 10);

				for (int r = 0; r < gameState.getWall_arr().size(); r++) {
					double wallX = gameState.getWall_arr().get(r).getWall_line().getStartX();
					if (gameState.getBlock_arr().get(r).blown == 0  && isColliding(gameState.getSnake().getSnake_arr().get(0),
							gameState.getWall_arr().get(r).getWall_line())) {
						gameState.getSnake().getSnake_arr().get(0).setCenterX(wallX - snakeOffset);
					}
				}

				for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
					double blockX = gameState.getBlock_arr().get(r).getShape().getTranslateX();
					if (gameState.getBlock_arr().get(r).blown == 0  && isColliding(gameState.getSnake().getSnake_arr().get(0),
							gameState.getBlock_arr().get(r).getShape())) {
					//	System.out.println("right block called");
						gameState.getSnake().getSnake_arr().get(0).setCenterX(currentX);
					}
				}

				updateSpheres(gameState.getSnake().getSnake_arr());
				gameState.getSnake().setPositionX(gameState.getSnake().getSnake_arr()
						.get(gameState.getSnake().getSnake_arr().size() - 1).getCenterX());
			}
		});

		scene_new.setOnMouseMoved(e -> {
			double mouseX = e.getX();
			double currentX = gameState.getSnake().getSnake_arr().get(0).getCenterX();
			double allowedCandidate = currentX;
			//System.out.println("\ncurrent : " + currentX);
			//System.out.println("mouse : " + mouseX);
			double checkOffset = 2;
			int steps = (int) ((mouseX - currentX) / checkOffset);
			if((steps < 0)) {
				checkOffset = -3;
				steps = -steps;
			}
			for (int i = 1; i < steps+1; i++) {
				double candidate = currentX + checkOffset * i;
				if(i == steps) {
					candidate = mouseX;
				}
			//	System.out.println("trying : " + candidate);
				boolean a = true , b = true;

				gameState.getSnake().getSnake_arr().get(0).setCenterX(candidate);
				
				for (int r = 0; r < gameState.getWall_arr().size(); r++) {
					if (isColliding(gameState.getSnake().getSnake_arr().get(0),
							gameState.getWall_arr().get(r).getWall_line())) {
						a = false;
					}
				}

				for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
					if (gameState.getBlock_arr().get(r).blown == 0  && isColliding(gameState.getSnake().getSnake_arr().get(0),
							gameState.getBlock_arr().get(r).getShape()))  {
						b = false;
					}
				}

				if (a && b) {
						allowedCandidate = candidate;
				}else {
					gameState.getSnake().getSnake_arr().get(0).setCenterX(allowedCandidate);
					//.out.println("candidate rejected");
					break;
				}
			}

			updateSpheres(gameState.getSnake().getSnake_arr());
			gameState.getSnake().setPositionX(gameState.getSnake().getSnake_arr()
					.get(gameState.getSnake().getSnake_arr().size() - 1).getCenterX());
		});

		primaryStage.setScene(scene_new);
	}

	// Changes the position of respective circles.
	public void updateSpheres(ArrayList<Circle> snakeHead) {
		for (int i = 1; i < snakeHead.size(); i++) {
			Circle topCircle = snakeHead.get(i - 1);
			Circle currCircle = snakeHead.get(i);
			currCircle.setCenterY(currCircle.getCenterY() + currCircle.getRadius());
			double ax = currCircle.getCenterX();
			double ay = currCircle.getCenterY();
			double bx = topCircle.getCenterX();
			double by = topCircle.getCenterY();
			if (!(ax == bx || ay == by)) {
				double d = Math.sqrt(Math.pow(ax - bx, 2) + Math.pow(ay - by, 2));
				double dt = snakeHead.get(i).getRadius() * 2;
				double t = dt / d;
				double xt = (1 - t) * bx + t * ax;
				double yt = (1 - t) * by + t * ay;
				currCircle.setCenterX(xt);
				currCircle.setCenterY(yt);
			} else {
				currCircle.setCenterX(topCircle.getCenterX());
				currCircle.setCenterY(topCircle.getCenterY() + currCircle.getRadius() * 2);
			}
		}
	}

	public void makeChoiceBox(Stage primaryStage) {
		choicebox = new ChoiceBox<String>();

		choicebox.getItems().add("Restart");
		choicebox.getItems().add("Main Menu");
		choicebox.getItems().add("Exit");
		choicebox.getItems().add("Menu");

		choicebox.setValue("Menu");

		// pane.getChildren().add(choicebox);

		//if (gameState.isResume == 0) {
			score_label = new Label("Score= " + gameState.score);
			score_label.setStyle("-fx-text-fill:white");
			choicebox.setTranslateY(10);
			score_label.setTranslateY(15);
			score_label.setTranslateX(415);

			length_label = new Label("Length= " + gameState.getSnake().getLength());

			length_label.setStyle("-fx-text-fill:white");
			length_label.setTranslateY(16);
			length_label.setTranslateX(330);
		//}

	}

	public void makeBlockStrip(ArrayList<Block> arr_block) {

		gameState.flag = gameState.flag + 5;
//		int hi = 0;
		for (int k = gameState.flag; k < gameState.flag + 5; k++) {
			Line line = new Line(50 + ((k - gameState.flag) * 100), -200, 50 + ((k - gameState.flag) * 100), 800 + 100);
			arr_block.get(k).getShape().setTranslateX(0 + ((k - gameState.flag) * 100));
			arr_block.get(k).getShape().setTranslateY(-200);

			gameState.pane.getChildren().addAll(arr_block.get(k).getShape(), arr_block.get(k).getValue());

			PathTransition transition = new PathTransition();
			transition.setNode(arr_block.get(k).getShape());
			transition.setDuration(Duration.seconds(6 - (gameState.getSnake().getLength() / 10) / 2));
			gameState.getBlock_arr().get(k).speed=6 - (gameState.getSnake().getLength() / 10) / 2;
			transition.setPath(line);

			arr_block.get(k).setTransition1(transition);
			arr_block.get(k).getTransition1().play();

			Line line2 = new Line(50 + ((k - gameState.flag) * 100), -200, 50 + ((k - gameState.flag) * 100),
					800 + 100);
			PathTransition transition2 = new PathTransition();
			transition2.setNode(arr_block.get(k).getValue());
			transition2.setDuration(Duration.seconds(6 - (gameState.getSnake().getLength() / 10) / 2));
			transition2.setPath(line2);

			arr_block.get(k).setTransition2(transition2);
			arr_block.get(k).getTransition2().play();
			transition2.play();
		}
	}

	protected void handleParticles() {
		for (particle dust : gameState.particles) {
			dust.animate();
		}
		for (int i = 0; i < gameState.particles.size(); i++) {
			if (gameState.particles.get(i).shouldDie) {
				gameState.pane.getChildren().remove(gameState.particles.get(i).c);
				gameState.particles.remove(gameState.particles.get(i));
				i--;
			}
		}
	}

	public void onUpdate(Stage primaryStage) throws IOException {

		// System.out.println("gameState.blockOn "+ gameState.blockOn);
		//System.out.println(gameState.magnetOn);
		gameState.mp.setCycleCount(MediaPlayer.INDEFINITE);
		gameState.mp.play();
		
		if(gameState.isResume==0) {
		handleParticles();
		if (gameState.blockOn == 1) {
			for (int q = 0; q < gameState.getBlock_arr().size(); q++) {
				if (isColliding(gameState.getSnake().getSnake_arr().get(0),
						gameState.getBlock_arr().get(q).getShape())) {
					gameState.getSnake().collisionWithBlock(gameState.pane, gameState.getBlock_arr().get(q), gameState,
							primaryStage, scene_game);
					break;
				}
			}

			if (gameState.ShieldOn == 1) {
				for (int w = 0; w < gameState.getSnake().getSnake_arr().size(); w++) {
					if (col == 0) {
						gameState.getSnake().getSnake_arr().get(w).setFill(Color.GOLD);

					} else if (col == 1) {
						gameState.getSnake().getSnake_arr().get(w).setFill(Color.RED);
					}
				}
				if (col == 1) {
					col = 0;
				} else {
					col = 1;
				}
			}

		}

		else {
			gameState.t = gameState.t + 1;
			
			if (gameState.magnetOn == 1) {
				System.out.println("Hello");
				for (int w = 0; w < gameState.getSnake().getSnake_arr().size(); w++) {
						System.out.println("hey");
						gameState.getSnake().getSnake_arr().get(w).setFill(Color.GREEN);
					
				}
			}

			if (gameState.ShieldOn == 1) {
				for (int w = 0; w < gameState.getSnake().getSnake_arr().size(); w++) {
					if (col == 0) {
						gameState.getSnake().getSnake_arr().get(w).setFill(Color.GOLD);
					} else if (col == 1) {
						gameState.getSnake().getSnake_arr().get(w).setFill(Color.RED);
					}
				}
				if (col == 1) {
					col = 0;
				} else {
					col = 1;
				}
			}


			if (gameState.t > gameState.old_timer + 400 && gameState.ShieldOn==1) {
				for (int w = 0; w < gameState.getSnake().getSnake_arr().size(); w++) {
					gameState.getSnake().getSnake_arr().get(w).setFill(Color.WHITE);
				}
				gameState.ShieldOn = 0;
				gameState.old_timer = 0;
			}
			
			
				if (gameState.t > gameState.old_timer2 + 400 && gameState.magnetOn==1) {
					for (int w = 0; w < gameState.getSnake().getSnake_arr().size(); w++) {
						gameState.getSnake().getSnake_arr().get(w).setFill(Color.WHITE);
					}
					gameState.magnetOn = 0;
					gameState.old_timer2 = 0;
				}
			
			
			if(gameState.magnetOn==1) {
				int v = 0;
				for (int r = 0; r < gameState.getToken_arr().size(); r++) {
					if (gameState.getToken_arr().get(r).getClass().getName().equals("application.BallToken")) {
						if (gameState.getToken_arr().get(r).getPicture().getTranslateY() < gameState.getSnake().getSnake_arr().get(0).getCenterY()+400 && 
								gameState.getToken_arr().get(r).getPicture().getTranslateY() > gameState.getSnake().getSnake_arr().get(0).getCenterY() - 200 &&
								gameState.getToken_arr().get(r).getPicture().getTranslateX() > gameState.getSnake().getSnake_arr().get(0).getCenterX() - 200 &&
								gameState.getToken_arr().get(r).getPicture().getTranslateX() < gameState.getSnake().getSnake_arr().get(0).getCenterX() + 200
								) {
							gameState.pane.getChildren()
									.remove(gameState.getToken_arr().get(r).getPicture());
							gameState.pane.getChildren()
									.remove(gameState.getToken_arr().get(r).getBall_label());
							v = v + gameState.getToken_arr().get(r).getBall_value();
							gameState.getToken_arr().remove(r);
							r = r - 1;
							gameState.index2 = gameState.index2 - 1;

						}
					}
				}
				for (int r = 0; r < v; r++) {
					Circle c = new Circle(10);
					c.setFill(Color.GREEN);
					c.setCenterX(gameState.getSnake().getPositionX());
					c.setCenterY(gameState.getSnake().getPositionY() + 20);
					gameState.getSnake().setLength(gameState.getSnake().getLength() + 1);
					gameState.getSnake().getSnake_arr().add(c);

					gameState.getSnake().setPositionY(gameState.getSnake().getPositionY() + 20);
					length_label.setText("Length= " + gameState.getSnake().getLength());
					gameState.pane.getChildren().add(c);
				}

				updateSpheres(gameState.getSnake().getSnake_arr());
			}
			
			
			if (gameState.t % 150 == 0) {
				int index = 0;
				Random rand = new Random();
				int x = rand.nextInt(5) + 1;
				int n;
				for (int r = 0; r < 5; r++) {
					if (r == x) {
						Random ran = new Random();
						n = ran.nextInt(gameState.getSnake().getLength()-1) + 1;
					} else {
						Random ran = new Random();
						n = ran.nextInt(5 + gameState.getSnake().getLength()) + 1;
					}

//					block.setBlockVal(n);
					Block block = new Block(n);
					gameState.getBlock_arr().add(block);
				}

				makeBlockStrip(gameState.getBlock_arr());

				Random ra = new Random();
				int z = ra.nextInt(2) + 1;
				for (int f = 0; f < z; f++) {
					int z1 = ra.nextInt(4) + 1;
					int z2 = ra.nextInt(200) + 1;
					int z3 = ra.nextInt(2) + 1;
					Wall wall = new Wall();
					wall.setWall_line(new Line(z1 * 100, -z2, z1 * 100, -z2 + z3 * 100));
					wall.getWall_line().setStroke(Color.WHITE);
					wall.getWall_line().setStrokeWidth(5);
					wall.makeWall(gameState, z1, z2, z3);
					wall.setWall_size(z3*100);
					gameState.getWall_arr().add(wall);
					gameState.pane.getChildren().add(wall.getWall_line());
				}
			}

			Random rand = new Random();
			spawnTokens();
			spawnBallToken();
		}
			
			
			// COLLISION STARTS
			handleBlockCollisions(primaryStage);

			for (int j = 0; j < gameState.getToken_arr().size(); j++) {
				if (isColliding(gameState.getSnake().getSnake_arr().get(0),
						gameState.getToken_arr().get(j).getPicture())) {
					gameState.pane.getChildren().remove(gameState.getToken_arr().get(j).getPicture());

					if (gameState.getToken_arr().get(j).getIsCollide() == 0) {
						if (gameState.getToken_arr().get(j).getClass().getName().equals("application.BallToken")) {
							gameState.pane.getChildren().remove(gameState.getToken_arr().get(j).getBall_label());
							gameState.getSnake().setLength(
									gameState.getSnake().getLength() + gameState.getToken_arr().get(j).getBall_value());
							for (int r = 0; r < gameState.getToken_arr().get(j).getBall_value(); r++) {
								Circle c = new Circle(10);
								c.setFill(Color.WHITE);
								c.setCenterX(gameState.getSnake().getPositionX());
								c.setCenterY(gameState.getSnake().getPositionY() + 20);
								gameState.getSnake().getSnake_arr().add(c);

								gameState.getSnake().setPositionY(gameState.getSnake().getPositionY() + 20);
								length_label.setText("Length= " + gameState.getSnake().getLength());
								gameState.pane.getChildren().add(c);
							}

							updateSpheres(gameState.getSnake().getSnake_arr());
						}

						else if (gameState.getToken_arr().get(j).getClass().getName().equals("application.DestroyToken")) {
							for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
								if (gameState.getBlock_arr().get(r).getShape().getTranslateY() < 800
										&& gameState.getBlock_arr().get(r).getShape().getTranslateY() > 0) {
									gameState.pane.getChildren().remove(gameState.getBlock_arr().get(r).getShape());
									gameState.score= gameState.score + gameState.getBlock_arr().get(r).getBlockVal();
									score_label.setText("Score= "+Integer.toString(gameState.score));
									gameState.pane.getChildren().remove(gameState.getBlock_arr().get(r).getValue());
									createBlastParticles(gameState.getBlock_arr().get(r).getShape().getFill(),
											gameState.getBlock_arr().get(r).getShape().getTranslateX(),
											gameState.getBlock_arr().get(r).getShape().getTranslateY(), gameState.pane);
									gameState.getBlock_arr().remove(r);
									r = r - 1;
									gameState.flag = gameState.flag - 1;
								}
							}
						}

						else if (gameState.getToken_arr().get(j).getClass().getName().equals("application.MagnetToken")) {
							gameState.magnetOn=1;
							if (gameState.getToken_arr().get(j).getIsCollide() == 0) {
								gameState.old_timer2 = gameState.t;
							}
						}

						else {
							if (gameState.getToken_arr().get(j).getIsCollide() == 0) {
								gameState.old_timer = gameState.t;
							}
							gameState.ShieldOn = 1;
						}
					}
					gameState.getToken_arr().get(j).setIsCollide(1);
				}
			}

			for (int q = 0; q < gameState.getBlock_arr().size(); q++) {
				if (gameState.getBlock_arr().get(q).getShape().getTranslateY() > 800) {
					gameState.pane.getChildren().remove(gameState.getBlock_arr().get(q));
					gameState.getBlock_arr().remove(q);
					gameState.flag = gameState.flag - 1;
				}
			}

			for (int q = 0; q < gameState.getToken_arr().size(); q++) {
				if (gameState.getToken_arr().get(q).getPicture().getTranslateY() > 800) {
					if (gameState.getToken_arr().get(q).getClass().getName().equals("application.BallToken")) {
						gameState.pane.getChildren().remove(gameState.getToken_arr().get(q).getBall_label());
					}

					gameState.pane.getChildren().remove(gameState.getToken_arr().get(q).getPicture());
					gameState.getToken_arr().remove(q);
					gameState.index2 = gameState.index2 - 1;
				}
			}

			for (int q = 0; q < gameState.getWall_arr().size(); q++) {
				if (gameState.getWall_arr().get(q).getWall_line().getTranslateY() > 800) {
					gameState.pane.getChildren().remove(gameState.getWall_arr().get(q).getWall_line());
					gameState.getWall_arr().remove(gameState.getWall_arr().get(q));
				}
			}

			if (choicebox.getValue().equals("Main Menu")) {

				gameState.timer.stop();
				primaryStage.setScene(scene_game);

			}
			
			if(choicebox.getValue().equals("Exit")) {

				PrintWriter out = new PrintWriter(new FileWriter("snakeinfo.txt"));
				out.println(Double.toString(gameState.getSnake().getSnake_arr().get(0).getCenterX()));
				out.println(Double.toString(gameState.getSnake().getSnake_arr().get(0).getCenterY()));
				out.println(Integer.toString(gameState.getSnake().getLength()));
				out.println(Double.toString(gameState.getSnake().time));
				out.println(Integer.toString(gameState.getSnake().value));
				out.close();
				
				PrintWriter out2 = new PrintWriter(new FileWriter("blockinfo.txt"));
				for(int a=0;a<gameState.getBlock_arr().size();a++) {
				out2.println(Integer.toString(gameState.getBlock_arr().get(a).getBlockVal()));
				out2.println(Double.toString(gameState.getBlock_arr().get(a).getShape().getTranslateX()));
				out2.println(Double.toString(gameState.getBlock_arr().get(a).getShape().getTranslateY()));
				out2.println(Integer.toString(gameState.getBlock_arr().get(a).blown));
				out2.println(Double.toString(gameState.getBlock_arr().get(a).speed));
				//out2.println("NEW");
				}
				out2.close();
				
				PrintWriter out3 = new PrintWriter(new FileWriter("wallinfo.txt"));
				for(int a=0;a<gameState.getWall_arr().size();a++) {
					out3.println(Double.toString(gameState.getWall_arr().get(a).getWall_line().getEndX()));
					out3.println(Double.toString(gameState.getWall_arr().get(a).getWall_line().getTranslateY()));
					out3.println(Integer.toString(gameState.getWall_arr().get(a).getWall_size()));
					out3.println(Double.toString(gameState.getWall_arr().get(a).speed));
				}
				out3.close();
				
				PrintWriter out4 = new PrintWriter(new FileWriter("tokeninfo.txt"));
				for(int a=0;a<gameState.getToken_arr().size();a++) {	
					out4.println(gameState.getToken_arr().get(a).name);
					out4.println(Double.toString(gameState.getToken_arr().get(a).getPicture().getTranslateX()));
					out4.println(Double.toString(gameState.getToken_arr().get(a).getPicture().getTranslateY()));
					out4.println(Integer.toString(gameState.getToken_arr().get(a).getIsCollide()));
					out4.println(Integer.toString(gameState.getToken_arr().get(a).getBall_value()));
					out4.println(Double.toString(gameState.getToken_arr().get(a).speed));
				}
				out4.close();
				
				PrintWriter out5 = new PrintWriter(new FileWriter("gamestateinfo.txt"));
				out5.println(Integer.toString(gameState.flag));
				out5.println(Integer.toString(gameState.score));
				out5.println(Integer.toString(gameState.index2));
				out5.println(Integer.toString(gameState.ShieldOn));
				out5.println(Integer.toString(gameState.old_timer));
				out5.println(Integer.toString(gameState.old_timer2));
				out5.println(Integer.toString(gameState.count2));
				out5.println(Integer.toString(gameState.isResume));
				out5.println(Integer.toString(gameState.blockOn));
				out5.println(Integer.toString(gameState.flagWall));
				out5.println(Integer.toString(gameState.magnetOn));
				out5.println(Integer.toString(gameState.t));
				out5.close();
				gameState.timer.stop();
				primaryStage.close();
			}

			if (choicebox.getValue().equals("Restart")) {
				ImageView SnakeLabel = new ImageView();
				Image snakeLabel = new Image("/application/snaketitle.jpg");
				// if(isResume==0) {
				SnakeLabel.setImage(snakeLabel);
				SnakeLabel.setFitWidth(500);
				SnakeLabel.setFitHeight(50);
				gameState.pane.getChildren().clear();
				gameState.score = 0;
				gameState.setSnake(new Snake(gameState));
				gameState.getSnake().makeSnake(gameState.pane);
				gameState.getSnake().setLength(4);
				makeChoiceBox(primaryStage);

				gameState.getBlock_arr().clear();
				gameState.getToken_arr().clear();

				gameState.flag = -5;
				gameState.index2 = 0;

				gameState.pane.getChildren().addAll(SnakeLabel, choicebox, score_label, length_label);

				scene_new.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			}
		}
	}

	private void createBlastParticles(Paint fill, double mouseX, double mouseY, Pane pane) {
//		System.out.println("create explosion");
		mouseX += 50;
		mouseY += 50;
		for (int i = 0; i < 200; i++) {
			Random rand = new Random();
			Circle c = new Circle(mouseX + (((double) (rand.nextInt(40)) - 21)),
					mouseY + (((double) (rand.nextInt(40)) - 21)), 2);
			c.setFill(fill);
			double speedX = ((double) (rand.nextInt(100)) - 50) / 50;
			double speedY = ((double) (rand.nextInt(100)) - 50) / 50;
			gameState.particles.add(new particle(c, speedX, speedY));
			pane.getChildren().add(gameState.particles.getLast().c);
		}
	}

	private void handleBlockCollisions(Stage primaryStage) {
		for (int q = 0; q < gameState.getBlock_arr().size(); q++) {
			if (isColliding(gameState.getSnake().getSnake_arr().get(0), gameState.getBlock_arr().get(q).getShape())) {
				gameState.getSnake().collisionWithBlock(gameState.pane, gameState.getBlock_arr().get(q), gameState,
						primaryStage, scene_game);
				break;
			}
		}
	}

	private void spawnBallToken() {
		if (gameState.t % 100 == 0) {
			BallToken = new ImageView();
			Token ball = new BallToken();
			ball.name="ball";
			Image balltoken = new Image("/application/ball.png");
			BallToken.setImage(balltoken);
			ball.setPicture(BallToken);
			gameState.getToken_arr().add(ball);
			MakeTokenStrip();
		}
	}

	private void spawnTokens() {
		if (gameState.t % 400 == 0) {
			if (gameState.count2 == 0) {
				// System.out.println("t= "+t);
				DestroyToken = new ImageView();
				Token destroy = new DestroyToken();
				destroy.name="destroy";
				Image destroytoken = new Image("/application/blast.png");
				DestroyToken.setImage(destroytoken);
				destroy.setPicture(DestroyToken);
				gameState.getToken_arr().add(destroy);
				gameState.count2 = 1;
			} else if (gameState.count2 == 1) {
				// System.out.println("t= "+t);
				ShieldToken = new ImageView();
				Token shield = new ShieldToken();
				shield.name="shield";
				Image shieldtoken = new Image("/application/shield.png");
				ShieldToken.setImage(shieldtoken);
				shield.setPicture(ShieldToken);
				gameState.getToken_arr().add(shield);
				gameState.count2 = 2;
			} else if (gameState.count2 == 2) {
				MagnetToken = new ImageView();
				Token magnet = new MagnetToken();
				magnet.name="magnet";
				Image magnettoken = new Image("/application/magnet.png");
				MagnetToken.setImage(magnettoken);
				magnet.setPicture(MagnetToken);
				gameState.getToken_arr().add(magnet);
				gameState.count2 = 0;
			}
			MakeTokenStrip();
		}
	}

	public void MakeTokenStrip() {
		Random r = new Random();
		int n = r.nextInt(450) + 20;
		int n2 = r.nextInt(90) + 100;
		Line line = new Line(n, -n2, n, 800 + (1100 - n2 - 800));
		if (gameState.getToken_arr().get(gameState.index2).getClass().getName()
				.compareTo("application.BallToken") == 0) {
			Line line2 = new Line(n, -(n2 + 30), n, 800 + (1100 - (n2 + 30) - 800));
			gameState.getToken_arr().get(gameState.index2).getBall_label().setTranslateX(n);
			gameState.getToken_arr().get(gameState.index2).getBall_label().setTranslateY(-(n2 + 30));
			gameState.getToken_arr().get(gameState.index2).getBall_label().setStyle("-fx-text-fill:white");
			gameState.getToken_arr().get(gameState.index2).getBall_label().setTranslateX(n);
			gameState.getToken_arr().get(gameState.index2).getBall_label().setTranslateY(-n2);
			gameState.pane.getChildren().add(gameState.getToken_arr().get(gameState.index2).getBall_label());
			PathTransition transition2 = new PathTransition();
			transition2.setNode(gameState.getToken_arr().get(gameState.index2).getBall_label());
			transition2.setDuration(Duration.seconds(6 - (gameState.getSnake().getLength() / 10) / 2));
			transition2.setPath(line2);
			
			gameState.getToken_arr().get(gameState.index2).setTransition2(transition2);
			transition2.play();
		}
		gameState.getToken_arr().get(gameState.index2).getPicture().setTranslateX(n);
		gameState.getToken_arr().get(gameState.index2).getPicture().setTranslateY(-n2);

		gameState.pane.getChildren().add(gameState.getToken_arr().get(gameState.index2).getPicture());
		PathTransition transition = new PathTransition();
		transition.setNode(gameState.getToken_arr().get(gameState.index2).getPicture());
		transition.setDuration(Duration.seconds(6 - (gameState.getSnake().getLength() / 10) / 2));
		gameState.getToken_arr().get(gameState.index2).speed= 6 - (gameState.getSnake().getLength() / 10) / 2;
		transition.setPath(line);
		transition.play();
		gameState.getToken_arr().get(gameState.index2).setTransition(transition);
		gameState.index2 = gameState.index2 + 1;
	}

	public boolean isColliding(Circle imageview, Rectangle rec) {
		return imageview.getBoundsInParent().intersects(rec.getBoundsInParent());
	}

	public boolean isColliding(Circle imageview, ImageView iv) {
		return imageview.getBoundsInParent().intersects(iv.getBoundsInParent());
	}

	public boolean isColliding(Rectangle r, Rectangle re) {
		return r.getBoundsInParent().intersects(re.getBoundsInParent());
	}

	public boolean isColliding(Circle snakeHead, Line l) {
		return snakeHead.getBoundsInParent().intersects(l.getBoundsInParent());
	}
}
