package application;

import java.io.Serializable;
import java.util.Random;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class BallToken extends Token implements Serializable{

	
	private int frequency = 4;
	private ImageView picture;
	
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public ImageView getPicture() {
		return picture;
	}
	public void setPicture(ImageView picture) {
		this.picture = picture;
		this.picture.setFitHeight(40);
		this.picture.setFitWidth(40);
		Random rand= new Random();
		int v= rand.nextInt(5)+1;
		this.setBall_value(v);
		this.setBall_label(new Label(Integer.toString(this.getBall_value())));
		
		
		
		
	}
}
