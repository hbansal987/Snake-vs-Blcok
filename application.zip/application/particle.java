package application;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class particle {
	Circle c;
	int animations;
	double speedX;
	double speedY;
	boolean shouldDie = false;
	int maxAnimations = 60;
	
	public particle(Circle cc,double xx,double yy) {
		animations = 0;
		speedX = xx;
		speedY = yy;
//		System.out.println(xx + "," + yy);
		c = cc;
//		cc.setRadius(30);
//		cc.setOpacity(0.05);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String s = "" + speedX + " " + speedY;
		return s;
	}
	
	public void animate() {
		if(animations > maxAnimations) {
//			System.out.println("ready to die");
			shouldDie = true;
		}else {
			animations++;
			c.setCenterX(c.getCenterX() + speedX);
			c.setCenterY(c.getCenterY() + speedY);
			speedY -= -0.05;
		}
	}
}
