package application;

import java.io.Serializable;
import javafx.animation.PathTransition;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Block implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int positionX;
	private int positionY;
	public Color color;
	private int blockVal;
	private Rectangle shape = new Rectangle();
	int blown = 0;
	private Label value;
	private PathTransition transition1;
	private PathTransition transition2;
	public double speed;

	public Block(int blockVal) {
		this.blockVal = blockVal;
		Label newlabel = new Label();
		newlabel.setText(Integer.toString(getBlockVal()));
		newlabel.setStyle(
				"-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 35px; -fx-font-family: \"Impact\";");
		newlabel.setTranslateX(-500);
		newlabel.setTranslateY(-500);
		setShape(new Rectangle(100, 100, findColor(blockVal)));
		getShape().setStroke(Color.BLACK);
		getShape().setStrokeWidth(3);
		getShape().setArcWidth(30.0);
		getShape().setArcHeight(20.0);
		setValue(newlabel);
	}

	
	public Color findColor(int i) {
//		Violet	148, 0, 211	#9400D3	
//		Indigo	75, 0, 130	#4B0082	
//		Blue	0, 0, 255	#0000FF	
//		Green	0, 255, 0	#00FF00	
//		Yellow	255, 255, 0	#FFFF00	
//		Orange	255, 127, 0	#FF7F00	
//		Red	255, 0 , 0	#FF0000
		
//		**************** ASSUME MAX blockVal to be 50 ***********
		int maxBlockVal =50;
		double r = 0;
		double g = 0 ;
		double b= 0 ;
		if(i <= 7) {
			// VIOLET
			r = 148;
			g = 0 ;
			b = 211;
			r = 148 - i*((148 - 75)/7);
			b = 211 - i*((211 - 130)/7);
		}else if(i <= 14) {
			// INDIGO
			i = i - 7;
			r = 75;
			g = 0 ;
			b = 130;
			r = 75 - i * ((75 - 0)/7);
			b = 130 + i*((255 - 130)/7);
		}else if(i <= 21) {
			// BLUE
			i = i - 14;
			r = 0;
			g = 0 ;
			b = 255;
			g = 0 + i*((255)/7);
			b = 130 - i*((130)/7);
		}else if(i <= 28) {
			// GREEN
			i = i - 21;
			r = 0;
			g = 255 ;
			b = 0;
			r = 0 + i*((255)/7);
		}else if(i <= 35) {
			// YELLOW
			i = i - 28;
			r = 255;
			g = 255;
			b = 0;
			g = 255 - i*((255 - 127)/7);
		}else{
			// ORANGE
			i = i - 35;
			r = 255;
			g = 127;
			b = 0;
			g = 127 - i*((127)/(maxBlockVal - 36));
		}
		
		r/=255;
		g/=255;
		b/=255;
		
		Color cc = new Color(r,g,b, 1);
		return cc;
	}

	public void setColor(Color c) {
		shape.setFill(c);
	}

	public void setColorViaValue() {
		setColor(findColor(blockVal));
	}

	public PathTransition getTransition2() {
		return transition2;
	}

	public void setTransition2(PathTransition transition2) {
		this.transition2 = transition2;
	}

	public PathTransition getTransition1() {
		return transition1;
	}

	public void setTransition1(PathTransition transition1) {
		this.transition1 = transition1;
	}

	public Label getValue() {
		return value;
	}

	public void setValue(Label value) {
		this.value = value;
	}

	public Rectangle getShape() {
		return shape;
	}

	public void setShape(Rectangle shape) {
		this.shape = shape;
	}

	public int getPositionX() {
		return positionX;
	}

	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}

	public int getPositionY() {
		return positionY;
	}

	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}

	public int getBlockVal() {
		return blockVal;
	}

	public void setBlockVal(int blockVal) {
		this.blockVal = blockVal;
	}

	public void updateColor() {
		// TODO Auto-generated method stub
		shape.setFill(findColor(blockVal));
	}
}
