package application;

import java.io.Serializable;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class DestroyToken extends Token implements Serializable{
//	public DestroyToken(ImageView pic) {
//		super(pic);
//		// TODO Auto-generated constructor stub
//	}
	private int frequency = 1;
	private ImageView picture;
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public ImageView getPicture() {
		return picture;
	}
	public void setPicture(ImageView picture) {
		this.picture = picture;
		this.picture.setFitHeight(40);
		this.picture.setFitWidth(40);
	}
}
