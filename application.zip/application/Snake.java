package application;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;
import java.util.Random;

//import blastGame.particle;
import javafx.scene.Scene;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Snake implements Serializable {
	/**
	 * 
	 */
	GameState gs;
	private static final long serialVersionUID = 1L;
	private double positionX; // assign center screen horizontally
	private double positionY; // assign apprporiate value here
	private int length;
	private Circle picture;
	private ArrayList<Circle> snake_arr = new ArrayList<Circle>();
	public double time;
	public int value = 0;
	int prevScore = -1;

	int snakeRadius = 10;

	public Snake(GameState gssss) {
		gs = gssss;
		length = 4;
	}

	public ArrayList<Circle> getSnake_arr() {
		return snake_arr;
	}

	public void setSnake_arr(ArrayList<Circle> snake_arr) {
		this.snake_arr = snake_arr;
	}

	public int getLength() {
		return length;
	}

	public Circle getPicture() {
		return picture;
	}

	public void setPicture(Circle picture) {
		this.picture = picture;
	}

	public double getPositionX() {
		return positionX;
	}

	public void setPositionX(double d) {
		this.positionX = d;
	}

	public double getPositionY() {
		return positionY;
	}

	public void setPositionY(double d) {
		this.positionY = d;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public void collisionWithWall(Wall w) {

	}
	
	public void collisionWithBlock(Pane pane, Block b, GameState gameState, Stage primaryStage, Scene scene_game) {

		// System.out.println("Hello");
		if (b.blown  == 0) {
			if (value == 0) {
				gameState.score = gameState.score + b.getBlockVal();
				Game.score_label.setText("score= " + gameState.score);
			}
			if (gameState.ShieldOn == 0) {
				if (value == 0) {
					setLength(getLength() - b.getBlockVal());
					Game.length_label.setText("Length= " + getLength());
					value = 1;
				}
				int length = getSnake_arr().size();

				// gameState.timer.stop();
				pauseAll(gameState);

				for (int w = 0; w < b.getBlockVal(); w++) {
					pane.getChildren().remove(getSnake_arr().get(length - 1 - w));
					// ADD ANOTHER KIND OF BLAST FOR SNAKE HERE
					createBlastParticles(5 ,10, getSnake_arr().get(0).getFill() ,  getSnake_arr().get(0).getCenterX() ,  getSnake_arr().get(0).getCenterY(), pane);
					getSnake_arr().remove(length - 1 - w);
					setPositionY(getPositionY() - 20);
					b.setBlockVal(b.getBlockVal() - 1);
					b.getValue().setText(Integer.toString(b.getBlockVal()));
					b.updateColor();
					time = System.currentTimeMillis();

					if (snakeDied(gameState, primaryStage, scene_game)) {
						break;
					}
					while (System.currentTimeMillis() - time < 30) {
					}
					gameState.blockOn = 1;
					return;
				}

				for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
					gameState.getBlock_arr().get(r).getTransition1().play();
					gameState.getBlock_arr().get(r).getTransition2().play();
				}

				for (int r = 0; r < gameState.getToken_arr().size(); r++) {
					gameState.getToken_arr().get(r).getTransition().play();
					if (gameState.getToken_arr().get(r).getTransition2() != null) {
						gameState.getToken_arr().get(r).getTransition2().play();
					}
				}

				for (int r = 0; r < gameState.getWall_arr().size(); r++) {
					gameState.getWall_arr().get(r).getTransition2().play();
				}
			}else {
				
			}
			b.blown = (1);
			burstBlock(b, pane);
		}
		gameState.blockOn = 0;
		value = 0;
	}
	
	private void createBlastParticles(Paint paint, double mouseX, double mouseY, Pane pane) {
		// TODO Auto-generated method stub
//		System.out.println("create explosion");
		mouseX +=50;
		mouseY +=50;
		for (int i = 0; i < 200; i++) {
			Random rand = new Random();
			Circle c = new Circle(mouseX + (((double) (rand.nextInt(40)) - 21)),
					mouseY + (((double) (rand.nextInt(40)) - 21)), 2);
			c.setFill(paint);
			double speedX = ((double) (rand.nextInt(100)) - 50) / 50;
			double speedY = ((double) (rand.nextInt(100)) - 50) / 50;
			gs.particles.add(new particle(c, speedX, speedY));
			pane.getChildren().add(gs.particles.getLast().c);
		}
	}
	
	private void createBlastParticles(int count , int max, Paint paint, double mouseX, double mouseY, Pane pane) {
		// TODO Auto-generated method stub
//		System.out.println("create explosion");
//		mouseX +=50;
//		mouseY +=50;
		for (int i = 0; i < count; i++) {
			Random rand = new Random();
			Circle c = new Circle(mouseX + (((double) (rand.nextInt(40)) - 21)),
					mouseY + (((double) (rand.nextInt(40)) - 21)), 2);
			c.setFill(paint);
			double speedX = ((double) (rand.nextInt(100)) - 50) / 50;
			double speedY = ((double) (rand.nextInt(100)) - 50) / 50;
			gs.particles.add(new particle(c, speedX, speedY));
			gs.particles.getLast().maxAnimations = max;
			pane.getChildren().add(gs.particles.getLast().c);
		}
	}
	
	public boolean snakeDied(GameState gameState, Stage primaryStage, Scene scene_game) {
		if (getSnake_arr().size() <= 0) {
		prevScore = gameState.score;
		gameState.timer.stop();
		gameState.score = 0;
		gameState.getBlock_arr().clear();
		gameState.getToken_arr().clear();
		gameState.flag = -5;
		gameState.index2 = 0;
		primaryStage.setScene(scene_game);
		gameState.mp.stop();
		return true;
		}else {
			return false;
		}
	}

	private void burstBlock(Block b, Pane pane) {
		// TODO Auto-generated method stub
		pane.getChildren().remove(b.getShape());
		pane.getChildren().remove(b.getValue());
		createBlastParticles(b.getShape().getFill() , b.getShape().getTranslateX(), b.getShape().getTranslateY(), pane);
	}

	private void pauseAll(GameState gameState) {
		// TODO Auto-generated method stub
		for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
			//System.out.println("gameState.getBlock_arr().size= "+ gameState.getBlock_arr().size());
			gameState.getBlock_arr().get(r).getTransition1().pause();
			gameState.getBlock_arr().get(r).getTransition2().pause();
		}

		for (int r = 0; r < gameState.getToken_arr().size(); r++) {
			gameState.getToken_arr().get(r).getTransition().pause();
			if (gameState.getToken_arr().get(r).getTransition2() != null) {
				gameState.getToken_arr().get(r).getTransition2().pause();
			}
		}

		for (int r = 0; r < gameState.getWall_arr().size(); r++) {
			gameState.getWall_arr().get(r).getTransition2().pause();
		}

	}

	public void increaseLength(int amt) {

	}

	public void usePower(Token token) {

	}

	public void display() {

	}

	public void makeSnake(Pane pane) {
		setPositionX(250);
		setPositionY(710);
		int snakeRadius = 10;

		for (int k = 0; k < 4; k++) {
			getSnake_arr().add(new Circle(250, 650 + (snakeRadius + snakeRadius) * k, snakeRadius));
			getSnake_arr().get(k).setFill(Color.WHITE);
			pane.getChildren().add(getSnake_arr().get(k));
		}
	}
}
